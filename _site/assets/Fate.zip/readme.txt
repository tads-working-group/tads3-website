TADS 3 FOR INFORM USERS
=======================

The following TADS 3 versions of the IBG tutorial games
William Tell and Captain Fate are supplied for the interest
of people familiar with Inform and interested in learning
something about TADS 3.

You may wish to study the TADS 3 source for these games in
conjunction with the source (and explanations) provided for
the corresponding games in the Inform Beginner's Guide by
Roger Firth and Sonja Kesserich. In any case, it is recommended
that you begin with the William Tell game, since the TADS 3
source for this game provides fuller comments for those
unfamiliar with TADS 3.

Partly for your (and my) amusement, and partly to demonstrate
some additional features of TADS 3, the TADS 3 source of the
Captain Fate game includes an optional extension in which
the superhero finally confronts the madman in the park.


If you discover any errors or have any comments, please send
them to me at eric.eve@hmc.ox.ac.uk.

The TADS 3 versions of these two games are distributed with
the kind permission of Roger Firth and Sonja Kesserich.

Eric Eve
19-Feb-05